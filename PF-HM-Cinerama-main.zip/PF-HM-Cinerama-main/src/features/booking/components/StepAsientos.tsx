﻿import { useMemo, useState, type FC, type MouseEvent } from 'react';
import { useAutoFocus } from '../../../shared/hooks/useAutoFocus';
import { useSpeakOnHover } from '../../../shared/hooks/useSpeakOnHover';
import { type Movie } from '../../../shared/types/movie';

interface StepAsientosProps {
  movie: Movie;
  cinema?: { name: string } | null;
  horario: string;
  totalTickets: number;
  onNext: (selectedSeats: string[]) => void;
}

export const StepAsientos: FC<StepAsientosProps> = ({ movie, cinema, horario, totalTickets, onNext }) => {
  const mainHeadingRef = useAutoFocus<HTMLHeadingElement>();
  const filas = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
  const columnas = Array.from({ length: 18 }, (_, i) => String(18 - i).padStart(2, '0'));
  const asientosOcupados = new Set([
    'A-11', 'C-08', 'C-01', 'D-17', 'D-16', 'E-08',
    'F-05', 'H-08', 'I-08', 'I-04', 'J-08', 'J-07', 'J-06', 'J-05',
  ]);
  const [seleccionados, setSeleccionados] = useState<Set<string>>(new Set());
  const [asientoEnVista, setAsientoEnVista] = useState<string>('E-09');
  const [sugerenciaActual, setSugerenciaActual] = useState(0);
  const [modalAbierto, setModalAbierto] = useState(false);
  const [mirada, setMirada] = useState({ x: 0, y: 0 });
  const { speak, stop } = useSpeakOnHover();

  const selectedSeats = Array.from(seleccionados).sort();
  const puedeContinuar = seleccionados.size === totalTickets;
  const asientoParaVista = selectedSeats[0] ?? asientoEnVista;

  const vistaVirtual = useMemo(() => {
    const [fila = 'E', columna = '09'] = asientoParaVista.split('-');
    const filaIndex = Math.max(filas.indexOf(fila), 0);
    const columnaNumero = Number(columna);
    const centroSala = 9.5;
    const desviacionColumnas = columnaNumero - centroSala;
    const desplazamientoLateral = desviacionColumnas * 0.58;
    const distanciaDesdePantalla = filas.length - 1 - filaIndex;
    const profundidadSala = 3.4 + distanciaDesdePantalla * 1.28;
    const distanciaReal = Math.sqrt(profundidadSala ** 2 + desplazamientoLateral ** 2);
    const anguloExacto = Math.atan2(desplazamientoLateral, profundidadSala) * (180 / Math.PI);
    const distanciaNormalizada = distanciaDesdePantalla / (filas.length - 1);
    const lateralNormalizado = desplazamientoLateral / 5.2;
    const zona = distanciaDesdePantalla <= 2 ? 'cerca de pantalla' : distanciaDesdePantalla <= 6 ? 'zona central' : 'zona alta';
    const screenWidth = Math.max(38, 88 - distanciaDesdePantalla * 5.4 - Math.abs(anguloExacto) * 0.15);
    const screenHeight = Math.max(21, 47 - distanciaDesdePantalla * 2.75);
    const screenTop = 10 + distanciaDesdePantalla * 1.65;
    const screenLeft = 50 - lateralNormalizado * (13 + distanciaNormalizada * 8);
    const floorStart = 51 + distanciaDesdePantalla * 1.65;
    const rowsVisible = distanciaDesdePantalla;
    const foregroundSeatScale = 1.55 - distanciaNormalizada * 0.52;
    const foregroundSeatWidth = 64 + (1 - distanciaNormalizada) * 14;
    const seatBackHeight = 28 - distanciaNormalizada * 8;
    const sideWallWidth = 16 + Math.abs(lateralNormalizado) * 6;
    const cameraLift = Math.round(24 + distanciaDesdePantalla * 6.4);

    return {
      asiento: asientoParaVista,
      fila,
      columna,
      filaIndex,
      distancia: distanciaReal.toFixed(1),
      angulo: Math.round(anguloExacto),
      anguloExacto,
      zona,
      screenWidth,
      screenHeight,
      screenTop,
      screenLeft,
      floorStart,
      rowsVisible,
      foregroundSeatScale,
      foregroundSeatWidth,
      seatBackHeight,
      sideWallWidth,
      cameraLift,
      lateralNormalizado,
      distanciaNormalizada,
    };
  }, [asientoParaVista, filas]);

  const handleSeatClick = (seatId: string) => {
    if (asientosOcupados.has(seatId)) return;
    setAsientoEnVista(seatId);

    setSeleccionados((prev) => {
      const nuevo = new Set(prev);
      if (nuevo.has(seatId)) {
        nuevo.delete(seatId);
      } else {
        if (nuevo.size >= totalTickets) return prev;
        nuevo.add(seatId);
      }
      return nuevo;
    });
  };

  const esPasillo = (fila: string, col: string) =>
    (parseInt(col, 10) === 15 || parseInt(col, 10) === 14 || parseInt(col, 10) === 13) && fila !== 'J';

  const crearSegmentosFila = (fila: string) => {
    const segmentos: string[][] = [];
    let segmentoActual: string[] = [];

    columnas.forEach((col) => {
      if (esPasillo(fila, col)) {
        if (segmentoActual.length > 0) segmentos.push(segmentoActual);
        segmentoActual = [];
        return;
      }

      const seatId = `${fila}-${col}`;
      if (asientosOcupados.has(seatId)) {
        if (segmentoActual.length > 0) segmentos.push(segmentoActual);
        segmentoActual = [];
        return;
      }

      segmentoActual.push(seatId);
    });

    if (segmentoActual.length > 0) segmentos.push(segmentoActual);
    return segmentos;
  };

  const handleSuggestedSeats = () => {
    const centroSala = 9.5;
    const filaIdeal = filas.length - 1 - 4.5;
    const candidatos = filas.flatMap((fila, filaIndex) =>
      crearSegmentosFila(fila).flatMap((segmento) => {
        if (segmento.length < totalTickets) return [];

        return Array.from({ length: segmento.length - totalTickets + 1 }, (_, index) => {
          const group = segmento.slice(index, index + totalTickets);
          const columnasGrupo = group.map((seatId) => Number(seatId.split('-')[1]));
          const centroGrupo = columnasGrupo.reduce((sum, col) => sum + col, 0) / columnasGrupo.length;
          const distanciaCentro = Math.abs(centroGrupo - centroSala);
          const distanciaFila = Math.abs(filaIndex - filaIdeal);
          const penalidadLateral = distanciaCentro * 1.8;
          const penalidadFila = distanciaFila * 1.25;

          return {
            group,
            score: penalidadLateral + penalidadFila,
          };
        });
      }),
    ).sort((a, b) => a.score - b.score);

    const mejoresOpciones = candidatos.slice(0, Math.min(10, candidatos.length));
    const opcion = mejoresOpciones[sugerenciaActual % Math.max(1, mejoresOpciones.length)] ?? candidatos[0];

    if (opcion) {
      setSeleccionados(new Set(opcion.group));
      setAsientoEnVista(opcion.group[0]);
      setSugerenciaActual((prev) => prev + 1);
      return;
    }

    const availableSeats = filas.flatMap((fila) =>
      columnas.map((col) => `${fila}-${col}`).filter((seatId) => {
        const [, col] = seatId.split('-');
        return !esPasillo(fila, col) && !asientosOcupados.has(seatId);
      }),
    );
    setSeleccionados(new Set(availableSeats.slice(0, totalTickets)));
    setAsientoEnVista(availableSeats[0] ?? 'E-09');
    setSugerenciaActual((prev) => prev + 1);
  };

  const handleModalMouseMove = (event: MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((event.clientY - rect.top) / rect.height - 0.5) * 2;
    setMirada({ x: Math.max(-1, Math.min(1, x)), y: Math.max(-1, Math.min(1, y)) });
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 animate-in fade-in duration-500 grid grid-cols-1 lg:grid-cols-4 gap-8">
      <h2 id="seat-selection-heading" ref={mainHeadingRef} tabIndex={-1} className="sr-only focus:outline-none">
        Seleccion de asientos para {movie.title}. Debes seleccionar {totalTickets} asiento{totalTickets === 1 ? '' : 's'}.
      </h2>

      <div className="lg:col-span-1 space-y-6 border-r border-zinc-900 pr-0 lg:pr-6">
        <div className="w-full aspect-[2/3] rounded-xl overflow-hidden border border-zinc-800 shadow-xl">
          <img src={movie.imageUrl} alt={`Poster de la pelicula ${movie.title}`} className="w-full h-full object-cover" />
        </div>
        <div className="space-y-1">
          <h3 className="text-2xl font-black text-white uppercase">{movie.title}</h3>
          <p className="text-zinc-400 text-sm font-semibold">{movie.duration ?? '2 hrs 7 min'} | {movie.rating ?? '+14'}</p>
          <p className="text-red-500 font-bold text-lg">{horario}</p>
          <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider">SALA: 03</p>
          {cinema && <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider">{cinema.name}</p>}
          <div className="pt-4 border-t border-zinc-900/60 mt-4">
            <p className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Progreso de seleccion:</p>
            <p className="text-sm font-black text-white mt-1">{seleccionados.size} de {totalTickets} asientos elegidos</p>
          </div>
        </div>
      </div>

      <div className="lg:col-span-3 flex flex-col items-center">
        <div className="w-full max-w-2xl rounded-3xl border border-zinc-800 bg-zinc-950 p-4 mb-6 text-sm text-zinc-300">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="flex items-center gap-3"><span className="inline-flex h-3.5 w-3.5 rounded-full bg-zinc-600 border border-zinc-700" />Disponible</div>
            <div className="flex items-center gap-3"><span className="inline-flex h-3.5 w-3.5 rounded-full bg-emerald-600 border border-emerald-500" />Seleccionado</div>
            <div className="flex items-center gap-3"><span className="inline-flex h-3.5 w-3.5 rounded-full bg-red-600 border border-red-700" />Ocupado</div>
          </div>
          <div className="mt-4 text-zinc-200">
            <p className="font-semibold">Asientos elegidos</p>
            <p>{selectedSeats.length > 0 ? selectedSeats.join(', ') : 'Ninguno seleccionado aun'}</p>
          </div>
          <div className="mt-5 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={handleSuggestedSeats}
              className="rounded-md bg-red-700 px-4 py-3 text-xs font-black uppercase tracking-widest text-white transition-colors hover:bg-red-600 focus:outline-none focus-visible:ring-4 focus-visible:ring-red-600"
            >
              Sugerir juntos
            </button>
            <button
              type="button"
              onClick={() => setSeleccionados(new Set())}
              className="rounded-md border border-zinc-700 px-4 py-3 text-xs font-black uppercase tracking-widest text-zinc-200 transition-colors hover:border-white focus:outline-none focus-visible:ring-4 focus-visible:ring-red-600"
            >
              Limpiar
            </button>
            <button
              type="button"
              onClick={() => setModalAbierto(true)}
              disabled={selectedSeats.length === 0}
              className={`rounded-md px-4 py-3 text-xs font-black uppercase tracking-widest transition-colors focus:outline-none focus-visible:ring-4 focus-visible:ring-red-600 ${
                selectedSeats.length > 0
                  ? 'bg-white text-black hover:bg-zinc-200'
                  : 'bg-zinc-900 text-zinc-600 cursor-not-allowed'
              }`}
            >
              Ver vista 3D
            </button>
          </div>
        </div>

        <p className="sr-only" aria-live="polite" aria-atomic="true">
          Has seleccionado {seleccionados.size} de {totalTickets} asientos.
        </p>

        <div className="w-full overflow-x-auto pb-6 text-center select-none" aria-describedby="seat-selection-summary" role="region" aria-labelledby="seat-selection-heading">
          <div className="inline-block min-w-[640px] space-y-2">
            {filas.map((fila) => (
              <div key={fila} className="flex items-center justify-center gap-1.5">
                <span className="w-6 text-right text-zinc-400 font-black text-sm pl-2">{fila}</span>
                {columnas.map((col) => {
                  const seatId = `${fila}-${col}`;
                  const ocupado = asientosOcupados.has(seatId);
                  const elegido = seleccionados.has(seatId);
                  const esPasillo = (parseInt(col, 10) === 15 || parseInt(col, 10) === 14 || parseInt(col, 10) === 13) && fila !== 'J';

                  if (esPasillo) return <div key={seatId} className="w-6 h-6 md:w-7 md:h-7" />;

                  return (
                    <button
                      key={seatId}
                      type="button"
                      disabled={ocupado}
                      onClick={() => handleSeatClick(seatId)}
                      onMouseEnter={() => speak(`Asiento ${fila}${col}, ${ocupado ? 'Ocupado' : elegido ? 'Seleccionado' : 'Disponible'}`)}
                      onFocus={() => speak(`Asiento ${fila}${col}, ${ocupado ? 'Ocupado' : elegido ? 'Seleccionado' : 'Disponible'}`)}
                      onMouseLeave={stop}
                      onBlur={stop}
                      aria-pressed={elegido}
                      aria-label={`Asiento ${fila}${col}, ${ocupado ? 'Ocupado' : elegido ? 'Seleccionado' : 'Disponible'}`}
                      className={`w-6 h-6 md:w-7 md:h-7 rounded-md transition-all text-[9px] flex items-center justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-white ${
                        ocupado
                          ? 'bg-red-600 text-white cursor-not-allowed'
                          : elegido
                            ? 'bg-emerald-600 text-white font-bold scale-105 shadow-md'
                            : 'bg-zinc-600 text-zinc-300 hover:bg-zinc-500'
                      }`}
                    >
                      {elegido ? col : ''}
                    </button>
                  );
                })}
              </div>
            ))}

            <div className="w-full max-w-2xl bg-zinc-700 text-zinc-900 font-black tracking-[0.5em] text-center py-2 text-2xl uppercase rounded-sm mt-5 mb-3 shadow-inner select-none">
              PANTALLA
            </div>

            <div className="flex items-center justify-center gap-1.5 pt-1 pr-6">
              <span className="w-6 md:w-7" />
              {columnas.map((col) => (
                <span key={col} className="w-6 md:w-7 text-center text-[10px] text-zinc-500 font-bold">{col}</span>
              ))}
            </div>
          </div>
        </div>

        <div id="seat-selection-summary" className="w-full max-w-2xl rounded-3xl border border-zinc-900 bg-zinc-950 p-4 text-zinc-300 mb-6">
          <p className="text-sm">Selecciona exactamente {totalTickets} asiento{totalTickets === 1 ? '' : 's'} para continuar.</p>

        </div>

        <div className="w-full flex justify-end max-w-2xl pt-6">
          <button
            type="button"
            onClick={() => onNext(selectedSeats)}
            disabled={!puedeContinuar}
            aria-label={puedeContinuar ? 'Continuar a dulceria' : `Debes seleccionar ${totalTickets - seleccionados.size} asiento${totalTickets - seleccionados.size === 1 ? '' : 's'} mas para continuar`}
            className={`font-bold text-xs tracking-widest uppercase px-8 py-3 rounded-md transition-all focus:outline-none focus-visible:ring-4 focus-visible:ring-red-600 ${
              puedeContinuar
                ? 'bg-red-700 hover:bg-red-600 text-white cursor-pointer shadow-lg'
                : 'bg-zinc-900 text-zinc-600 cursor-not-allowed'
            }`}
          >
            {seleccionados.size < totalTickets ? `Faltan ${totalTickets - seleccionados.size} asientos` : 'Siguiente'}
          </button>
        </div>
      </div>

      {modalAbierto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 px-4 py-6" role="dialog" aria-modal="true" aria-labelledby="seat-vr-title">
          <div className="w-full max-w-6xl overflow-hidden border border-zinc-800 bg-black shadow-2xl">
            <div className="flex flex-col gap-3 border-b border-zinc-900 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.25em] text-red-500">Realidad aumentada</p>
                <h3 id="seat-vr-title" className="mt-1 text-xl font-black uppercase text-white">
                  Vista desde el asiento {vistaVirtual.asiento}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setModalAbierto(false)}
                className="self-start rounded-md border border-zinc-700 px-4 py-2 text-xs font-black uppercase tracking-widest text-white hover:border-white focus:outline-none focus-visible:ring-4 focus-visible:ring-red-600 sm:self-auto"
              >
                Cerrar
              </button>
            </div>

            <div className="grid lg:grid-cols-[1fr_280px]">
              <div
                className="relative min-h-[420px] cursor-grab overflow-hidden bg-black lg:min-h-[560px]"
                onMouseMove={handleModalMouseMove}
                onMouseLeave={() => setMirada({ x: 0, y: 0 })}
              >
                <div
                  className="absolute inset-0 origin-center transition-transform duration-200 ease-out"
                  style={{
                    transform: `translate3d(${mirada.x * -10}px, ${mirada.y * -8}px, 0) scale(1.01)`,
                  }}
                >
                  <div className="absolute inset-0 bg-[linear-gradient(90deg,#130306_0%,#070707_18%,#09090b_50%,#070707_82%,#130306_100%)]" />
                  <div className="absolute left-[8%] right-[8%] top-0 h-[26%] bg-[radial-gradient(circle_at_50%_0%,rgba(255,255,255,0.18),transparent_58%)]" />
                  <div className="absolute left-[12%] right-[12%] top-0 h-[18%] bg-[repeating-linear-gradient(90deg,rgba(255,255,255,0.08)_0_2px,transparent_2px_58px)] opacity-35 [clip-path:polygon(7%_0,93%_0,100%_100%,0_100%)]" />

                  {[18, 34, 50, 66, 82].map((left) => (
                    <span
                      key={`ceiling-light-${left}`}
                      className="absolute top-[7%] h-1.5 w-1.5 rounded-full bg-white shadow-[0_0_18px_8px_rgba(255,255,255,0.24)]"
                      style={{ left: `${left}%` }}
                    />
                  ))}

                  <div
                    className="absolute left-0 top-0 h-full bg-[linear-gradient(90deg,rgba(127,29,29,0.72),rgba(24,24,27,0.16),rgba(0,0,0,0))]"
                    style={{ width: `${vistaVirtual.sideWallWidth}%` }}
                  />
                  <div
                    className="absolute right-0 top-0 h-full bg-[linear-gradient(270deg,rgba(127,29,29,0.72),rgba(24,24,27,0.16),rgba(0,0,0,0))]"
                    style={{ width: `${vistaVirtual.sideWallWidth}%` }}
                  />

                  <div
                    className="absolute -translate-x-1/2 overflow-hidden border border-zinc-500 bg-zinc-300 shadow-[0_0_95px_rgba(255,255,255,0.24)]"
                    style={{
                      left: `${vistaVirtual.screenLeft + mirada.x * 1.5}%`,
                      top: `${vistaVirtual.screenTop + mirada.y * 0.8}%`,
                      width: `${vistaVirtual.screenWidth}%`,
                      height: `${vistaVirtual.screenHeight}%`,
                    }}
                  >
                    <div className="h-full w-full bg-[radial-gradient(circle_at_50%_42%,#f8fafc,#b7bac4_42%,#3f3f46_100%)]" />
                    <div className="absolute inset-x-0 bottom-0 h-[22%] bg-black/20" />
                  </div>

                  <div
                    className="absolute h-1 bg-red-700 shadow-[0_0_24px_rgba(220,38,38,0.9)]"
                    style={{
                      left: `${Math.max(8, vistaVirtual.screenLeft - vistaVirtual.screenWidth / 2)}%`,
                      right: `${Math.max(8, 100 - (vistaVirtual.screenLeft + vistaVirtual.screenWidth / 2))}%`,
                      top: `${vistaVirtual.screenTop + vistaVirtual.screenHeight + 3}%`,
                    }}
                  />

                  <div
                    className="absolute left-1/2 -translate-x-1/2 bg-[linear-gradient(180deg,rgba(127,29,29,0.28),rgba(0,0,0,0.05)),repeating-linear-gradient(90deg,rgba(255,255,255,0.045)_0_1px,transparent_1px_48px)]"
                    style={{
                      top: `${vistaVirtual.floorStart}%`,
                      height: `${98 - vistaVirtual.floorStart}%`,
                      width: `${90 - vistaVirtual.distanciaNormalizada * 20}%`,
                      clipPath: 'polygon(10% 0, 90% 0, 100% 100%, 0 100%)',
                    }}
                  />

                  {Array.from({ length: vistaVirtual.rowsVisible }, (_, index) => {
                    const progress = vistaVirtual.rowsVisible <= 1 ? 1 : index / (vistaVirtual.rowsVisible - 1);
                    const rowTop = vistaVirtual.floorStart + 6 + progress * (34 - vistaVirtual.distanciaNormalizada * 7);
                    const rowWidth = 36 + progress * 34;
                    const seatHeight = 3.4 + progress * 2.2;
                    return (
                      <div
                        key={`visible-row-${index}`}
                        className="absolute left-1/2 grid -translate-x-1/2 grid-cols-9 gap-2"
                        style={{
                          top: `${rowTop}%`,
                          width: `${rowWidth}%`,
                          opacity: 0.3 + progress * 0.42,
                        }}
                      >
                        {Array.from({ length: 9 }, (_, seatIndex) => (
                          <span
                            key={`visible-seat-${index}-${seatIndex}`}
                            className="rounded-t-md border-t border-zinc-500/30 bg-[linear-gradient(180deg,#3f3f46,#18181b_62%,#050505)] shadow-[0_-8px_18px_rgba(0,0,0,0.55)]"
                            style={{ height: `${seatHeight}vh` }}
                          />
                        ))}
                      </div>
                    );
                  })}

                  <div
                    className="absolute bottom-[-6%] left-1/2 flex -translate-x-1/2 items-end justify-center gap-[3%]"
                    style={{
                      width: `${vistaVirtual.foregroundSeatWidth}%`,
                      height: `${vistaVirtual.seatBackHeight}%`,
                    }}
                  >
                    {[0, 1, 2].map((seatIndex) => (
                      <span
                        key={`foreground-seat-${seatIndex}`}
                        className="h-full flex-1 rounded-t-[38%] bg-[radial-gradient(circle_at_50%_0%,#4b4b54,#09090b_68%)] shadow-[0_-18px_36px_rgba(0,0,0,0.78)]"
                      />
                    ))}
                  </div>
                </div>

                <div className="absolute left-5 top-5 rounded-md bg-black/70 px-4 py-3 text-white backdrop-blur">
                  <p className="text-xs font-black uppercase tracking-[0.2em] text-red-500">Asiento seleccionado</p>
                  <p className="mt-1 text-2xl font-black">{vistaVirtual.asiento}</p>
                </div>
                <p className="absolute bottom-5 left-5 right-5 text-center text-xs font-bold uppercase tracking-[0.2em] text-zinc-400">
                  Mueve el mouse para mirar la sala
                </p>
              </div>

              <aside className="border-t border-zinc-900 p-5 text-zinc-300 lg:border-l lg:border-t-0">
                <p className="text-xs font-black uppercase tracking-[0.2em] text-zinc-500">Datos de perspectiva</p>
                <div className="mt-5 space-y-4">
                  <div>
                    <p className="text-zinc-500">Distancia a pantalla</p>
                    <p className="text-2xl font-black text-white">{vistaVirtual.distancia} m</p>
                  </div>
                  <div>
                    <p className="text-zinc-500">Angulo de vision</p>
                    <p className="text-2xl font-black text-white">{vistaVirtual.angulo > 0 ? `+${vistaVirtual.angulo}` : vistaVirtual.angulo} deg</p>
                  </div>
                  <div>
                    <p className="text-zinc-500">Ubicacion</p>
                    <p className="text-lg font-bold text-white">Fila {vistaVirtual.fila}, asiento {vistaVirtual.columna}</p>
                    <p className="text-sm text-zinc-400">{vistaVirtual.zona}</p>
                    <p className="mt-2 text-sm text-zinc-400">Altura visual: {vistaVirtual.cameraLift}%</p>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};



